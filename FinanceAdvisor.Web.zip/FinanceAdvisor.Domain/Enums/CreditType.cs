﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum CreditType
    {
        Mortgage = 0,
        Individual = 1,

    }
}
