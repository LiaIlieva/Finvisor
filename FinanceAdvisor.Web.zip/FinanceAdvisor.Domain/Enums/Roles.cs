﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinanceAdvisor.Domain.Enums
{
    public enum Roles
    {
        User,
        Advisor,
        Admin
        
    }
}
