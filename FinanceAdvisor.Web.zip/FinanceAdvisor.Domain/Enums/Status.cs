﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum Status
    {
        Pending,
        Confirmed,
        Completed,
        Cancelled
    }

}
