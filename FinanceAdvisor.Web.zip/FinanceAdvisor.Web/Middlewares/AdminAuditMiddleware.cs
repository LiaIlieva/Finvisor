﻿namespace FinanceAdvisor.Web.Middlewares
{
    public class AdminAuditMiddleware
    {
    }
}
