using FinanceAdvisor.Domain.Enums;

public class CreateApplicationUserViewModel
{
    
    public string UserName { get; set; } = "";
    public string Email { get; set; } = "";
    
}
