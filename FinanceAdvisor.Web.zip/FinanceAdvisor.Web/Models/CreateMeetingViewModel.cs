
public class CreateMeetingViewModel
{
    public Guid CreditConsultationCycleId { get; set; }
    public DateTime Date { get; set; }
    public string? Topic { get; set; }
    public string? Notes { get; set; }
}