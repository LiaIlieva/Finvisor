﻿namespace FinanceAdvisor.Web.Models
{
    public class UpdateApplicationUserViewModel
    {
        public string? Email { get; set; }
        public string? UserName { get; set; }

        public bool IsDeleted { get; set; }
    }

}

