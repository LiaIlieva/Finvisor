﻿namespace FinanceAdvisor.Application
{
    public class Class1
    {

    }
}
