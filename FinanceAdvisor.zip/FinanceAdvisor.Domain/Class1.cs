﻿namespace FinanceAdvisor.Domain
{
    public class Class1
    {

    }
}
