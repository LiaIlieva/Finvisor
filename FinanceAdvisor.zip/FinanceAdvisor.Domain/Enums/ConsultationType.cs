﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum ConsultationType
    {
        CreditAdvisory,
        InvestmentAdvisory,
        SecurityAdvisory,
    }
}
