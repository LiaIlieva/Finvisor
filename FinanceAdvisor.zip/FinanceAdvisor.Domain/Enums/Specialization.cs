﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum Specialization
    {
        Credit = 0,
        Investment = 1,
        Security = 2,
    }
}
