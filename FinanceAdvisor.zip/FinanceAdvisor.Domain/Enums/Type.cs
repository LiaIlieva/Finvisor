﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum Type
    {
        Initial = 0,
        Secondary = 1,
        Final = 2,
    }
}
