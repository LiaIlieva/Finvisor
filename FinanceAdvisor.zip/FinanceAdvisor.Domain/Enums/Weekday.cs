﻿namespace FinanceAdvisor.Domain.Enums
{
    public enum Weekday
    {
        Monday = 1,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    }
}
