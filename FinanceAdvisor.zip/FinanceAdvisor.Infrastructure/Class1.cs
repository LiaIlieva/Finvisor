﻿namespace FinanceAdvisor.Infrastructure
{
    public class Class1
    {

    }
}
